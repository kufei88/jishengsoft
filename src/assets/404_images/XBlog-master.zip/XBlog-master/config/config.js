module.exports = {
    mongodb: "mongodb://uid:password@ip:port/path",
    baiduAK:"yFKaMEQnAYc1hA0AKaNyHGd4HTQgTNvO",
    qiniu: {
        accessKey:'xxxxxxxxxxxxxx',
        secretKey:'xxxxxxxxxxxxxxx',
        bucket: 'js-css',
        origin: 'xxxxxxxxxxxxxxxx',
    }
};
