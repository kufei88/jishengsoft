<template>
    <div class="index-bottom-info text-center text-overflow">
        <p><i class="fa fa-copyright"></i><span> 2017-2018 All Rights Reserved.</span><span class="hidden-xs">Designed by billyhu.鄂ICP备16001878号.</span></p>
    </div>
</template>
<style scoped lang="scss">
    .index-bottom-info {
        user-select: none;
        -webkit-user-select: none;
        position: relative;
        width: auto;
        color: #eee;
        font-size: 12px;
        p {
            overflow: hidden;
        }
    }
</style>
