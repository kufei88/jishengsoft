import IndexSection from './src/index-section.vue';
module.exports = IndexSection;
