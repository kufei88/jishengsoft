import Button from './src/button.vue';
module.exports = Button;
