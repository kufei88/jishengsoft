import DatetimePicker from './src/datetime-picker.vue';
module.exports = DatetimePicker;
