import TabContainerItem from './src/tab-container-item.vue';
module.exports = TabContainerItem;
