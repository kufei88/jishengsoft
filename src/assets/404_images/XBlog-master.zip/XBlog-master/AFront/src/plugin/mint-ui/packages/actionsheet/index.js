import Actionsheet from './src/actionsheet.vue';
module.exports = Actionsheet;
