import SwipeItem from '../swipe/src/swipe-item.vue';
import 'mint-ui/src/style/empty.css';

module.exports = SwipeItem;
