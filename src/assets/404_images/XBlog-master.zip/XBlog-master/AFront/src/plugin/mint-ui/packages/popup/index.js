import Popup from './src/popup.vue';
module.exports = Popup;
