import PaletteButton from './src/palette-button.vue';
module.exports = PaletteButton;
