import IndexList from './src/index-list.vue';
module.exports = IndexList;
