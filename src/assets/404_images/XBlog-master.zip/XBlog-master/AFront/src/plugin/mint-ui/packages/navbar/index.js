import Navbar from './src/navbar.vue';
module.exports = Navbar;
