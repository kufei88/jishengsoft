import Swipe from './src/swipe.vue';
module.exports = Swipe;
