import TabContainer from './src/tab-container.vue';
module.exports = TabContainer;
