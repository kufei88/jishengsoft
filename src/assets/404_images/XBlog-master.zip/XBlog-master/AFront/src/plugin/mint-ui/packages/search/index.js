import Search from './src/search.vue';
module.exports = Search;
