import Picker from './src/picker.vue';
module.exports = Picker;
