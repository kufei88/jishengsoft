import TabContainer from './src/switch.vue';
module.exports = TabContainer;
