import Loadmore from './src/loadmore.vue';
module.exports = Loadmore;
