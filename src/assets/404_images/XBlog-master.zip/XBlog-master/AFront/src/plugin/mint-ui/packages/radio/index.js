import Radio from './src/radio.vue';
module.exports = Radio;
